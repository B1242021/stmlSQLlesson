// FastAPI 後端 API 位置
const API_BASE = 'http://127.0.0.1:8000/api';

let currentUser = null;
let calendar = null;

// 把 Date 轉成 YYYY-MM-DD
function formatDate(dateObj) {
    return dateObj.getFullYear() + '-' +
        String(dateObj.getMonth() + 1).padStart(2, '0') + '-' +
        String(dateObj.getDate()).padStart(2, '0');
}

// 取得今天日期字串
function todayStr() {
    return formatDate(new Date());
}

// 把 YYYY-MM-DD 轉成本地 Date
function parseLocalDate(dateStr) {
    return new Date(`${dateStr}T00:00:00`);
}

// 判斷指定日期與小時是否已經過去
function isPastSlot(date, hour) {
    const now = new Date();
    const selectedTime = new Date(`${date}T${String(hour).padStart(2, '0')}:00:00`);
    return selectedTime < now;
}

// 判斷指定時段是否不在開放時間
function isInvalidOpenHour(date, hour) {
    const dateObj = parseLocalDate(date);
    const day = dateObj.getDay();

    // 假日：13:00 ~ 18:00
    if (day === 0 || day === 6) {
        return hour < 13 || hour >= 19;
    }

    // 平日：09:00 ~ 20:00
    return hour < 9 || hour >= 21;
}

// 設定快速預約日期不能選過去日期
function setupQuickBookingLimit() {
    const dateInput = document.getElementById('book-date');
    const hourSelect = document.getElementById('book-hour');

    if (!dateInput || !hourSelect) return;

    dateInput.min = todayStr();

    if (!dateInput.value || dateInput.value < todayStr()) {
        dateInput.value = todayStr();
    }

    updateHourOptions();

    if (!dateInput.dataset.bound) {
        dateInput.addEventListener('change', function () {
            if (dateInput.value < todayStr()) {
                alert('不能選擇過去日期');
                dateInput.value = todayStr();
            }

            updateHourOptions();
        });

        dateInput.dataset.bound = "true";
    }
}

// 禁用已過去時間與非開放時間
function updateHourOptions() {
    const dateInput = document.getElementById('book-date');
    const hourSelect = document.getElementById('book-hour');

    if (!dateInput || !hourSelect) return;

    const date = dateInput.value;

    Array.from(hourSelect.options).forEach(option => {
        if (!option.value) return;

        const hour = parseInt(option.value);

        option.disabled =
            !date ||
            date < todayStr() ||
            isPastSlot(date, hour) ||
            isInvalidOpenHour(date, hour);
    });

    if (
        hourSelect.value &&
        hourSelect.options[hourSelect.selectedIndex] &&
        hourSelect.options[hourSelect.selectedIndex].disabled
    ) {
        hourSelect.value = "";
    }
}

// 行事曆上用灰色背景顯示過去時段
function addPastBackground() {
    if (!calendar) return;

    const now = new Date();
    const viewStart = calendar.view.activeStart;
    const viewEnd = calendar.view.activeEnd;

    if (viewStart < now) {
        calendar.addEvent({
            id: '__past_background__',
            start: viewStart,
            end: now < viewEnd ? now : viewEnd,
            display: 'background',
            backgroundColor: '#d0d0d0'
        });
    }
}

// 頁面載入後初始化日期限制
document.addEventListener('DOMContentLoaded', function () {
    setupQuickBookingLimit();
});

// 登入
async function login() {
    const student_id = document.getElementById('login-id').value.trim();
    const password = document.getElementById('login-password').value.trim();

    if (!student_id || !password) {
        alert('請輸入帳號與密碼');
        return;
    }

    try {
        const res = await fetch(`${API_BASE}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ student_id, password })
        });

        const data = await res.json();

        if (!res.ok) {
            alert(data.detail || data.message || '登入失敗');
            return;
        }

        currentUser = data;

        document.getElementById('auth-section').classList.add('hidden');
        document.getElementById('app-section').classList.remove('hidden');

        document.getElementById('welcome-msg').innerText = `歡迎，${currentUser.student_id}！`;

        setupQuickBookingLimit();
        initCalendar();

        // 管理員登入後才顯示管理區
        if (currentUser.role === 'admin') {
            document.getElementById('admin-section').classList.remove('hidden');
            loadPendingUsers();
            loadAllUsers();
        }
    } catch (err) {
        alert('連不到後端，請確認 FastAPI 是否正在 8000 埠執行');
    }
}

// 非學生送出帳號申請
async function applyStaff() {
    const student_id = document.getElementById('apply-id').value.trim();
    const password = document.getElementById('apply-password').value.trim();
    const real_name = document.getElementById('apply-name').value.trim();
    const phone = document.getElementById('apply-phone').value.trim();
    const reason = document.getElementById('apply-reason').value.trim();

    if (!student_id || !password || !real_name || !phone || !reason) {
        alert('請完整填寫申請資料');
        return;
    }

    try {
        const res = await fetch(`${API_BASE}/apply_staff`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ student_id, password, real_name, phone, reason })
        });

        const data = await res.json();
        alert(data.message || data.detail);

        if (res.ok) {
            document.getElementById('apply-id').value = '';
            document.getElementById('apply-password').value = '';
            document.getElementById('apply-name').value = '';
            document.getElementById('apply-phone').value = '';
            document.getElementById('apply-reason').value = '';
        }
    } catch (err) {
        alert('連不到後端，請確認 FastAPI 是否正在 8000 埠執行');
    }
}

// 登出
function logout() {
    location.reload();
}

// 快速預約
async function manualBook() {
    const date = document.getElementById('book-date').value;
    const hour = document.getElementById('book-hour').value;
    const court = document.getElementById('book-court').value;

    if (!date || !hour || !court) {
        alert('請完整選擇日期、時間與場地');
        return;
    }

    const h = parseInt(hour);

    if (date < todayStr()) {
        alert('不能預約過去日期');
        return;
    }

    if (isPastSlot(date, h)) {
        alert('不能預約已經過去的時段');
        return;
    }

    if (isInvalidOpenHour(date, h)) {
        alert('此時段不在開放時間內');
        return;
    }

    const res = await fetch(`${API_BASE}/reservations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            student_id: currentUser.student_id,
            court_name: court,
            date: date,
            hour: h
        })
    });

    const data = await res.json();
    alert(data.message || data.detail);
    loadReservations();
}

// 初始化行事曆
function initCalendar() {
    const calendarEl = document.getElementById('calendar');

    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'timeGridWeek',
        slotMinTime: '09:00:00',
        slotMaxTime: '21:00:00',
        allDaySlot: false,
        height: 650,
        nowIndicator: true,

        // 今天以前不能選
        validRange: {
            start: todayStr()
        },

        // 開放時間
        businessHours: [
            {
                daysOfWeek: [1, 2, 3, 4, 5],
                startTime: '09:00',
                endTime: '21:00'
            },
            {
                daysOfWeek: [0, 6],
                startTime: '13:00',
                endTime: '19:00'
            }
        ],

        datesSet: function () {
            setupQuickBookingLimit();
            loadReservations();
        },

        // 點空白格建立預約
        dateClick: async function (info) {
            const clickedTime = info.date;
            const now = new Date();

            if (clickedTime < now) return;

            const dateObj = new Date(info.date);
            const dateStr = formatDate(dateObj);
            const hour = dateObj.getHours();

            if (dateStr < todayStr()) return;
            if (isPastSlot(dateStr, hour)) return;

            if (isInvalidOpenHour(dateStr, hour)) {
                alert('此時段不在開放時間內');
                return;
            }

            const court = prompt(`您選擇了 ${dateStr} 的 ${hour}:00 時段。請輸入要預約的場地（A場 或 B場）：`);

            if (!court) return;

            if (court !== 'A場' && court !== 'B場') {
                alert('場地只能輸入 A場 或 B場');
                return;
            }

            const res = await fetch(`${API_BASE}/reservations`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    student_id: currentUser.student_id,
                    court_name: court,
                    date: dateStr,
                    hour: hour
                })
            });

            const data = await res.json();
            alert(data.message || data.detail);
            loadReservations();
        },

        // 點已有預約：加入、退出、取消
        eventClick: async function (info) {
            const resId = info.event.extendedProps.reservation_id;

            if (!resId) return;

            if (info.event.start < new Date()) {
                alert('過去的預約不能操作');
                return;
            }

            const participantsCount = info.event.extendedProps.participants_count;
            const courtName = info.event.extendedProps.court_name;
            const participantList = info.event.extendedProps.participants;
            const hostId = info.event.extendedProps.host_id;

            // 管理員可以取消任何預約
            if (currentUser.role === 'admin') {
                if (confirm(`管理員權限：確定取消【${courtName}】這筆預約嗎？`)) {
                    await deleteReservation(resId);
                }
                return;
            }

            // 使用者已經在揪團內
            if (participantList.includes(currentUser.student_id)) {

                // 發起人可以取消整筆預約
                if (hostId === currentUser.student_id) {
                    if (confirm(`你是發起人。確定取消【${courtName}】整筆預約嗎？`)) {
                        await deleteReservation(resId);
                    }
                    return;
                }

                // 非發起人只能退出揪團
                if (confirm(`你已經在【${courtName}】的揪團中。確定退出揪團嗎？`)) {
                    const res = await fetch(`${API_BASE}/reservations/${resId}/leave`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ student_id: currentUser.student_id })
                    });

                    const data = await res.json();
                    alert(data.message || data.detail);
                    loadReservations();
                }

                return;
            }

            // 使用者還沒加入，點擊就是加入揪團
            if (participantsCount >= 14) {
                alert('此揪團已滿 14 人');
                return;
            }

            if (confirm(`【${courtName}】目前有 ${participantsCount}/14 人。確定加入揪團嗎？`)) {
                const res = await fetch(`${API_BASE}/reservations/${resId}/join`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ student_id: currentUser.student_id })
                });

                const data = await res.json();
                alert(data.message || data.detail);
                loadReservations();
            }
        }
    });

    calendar.render();
    loadReservations();
}

// 取消整筆預約
async function deleteReservation(resId) {
    const res = await fetch(`${API_BASE}/reservations/${resId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ student_id: currentUser.student_id })
    });

    const data = await res.json();
    alert(data.message || data.detail);
    loadReservations();
}

// 載入預約資料
async function loadReservations() {
    if (!calendar) return;

    const res = await fetch(`${API_BASE}/reservations`);
    const data = await res.json();

    calendar.removeAllEvents();
    addPastBackground();

    data.forEach(item => {
        const startDateTime = `${item.date}T${String(item.hour).padStart(2, '0')}:00:00`;
        const endDateTime = `${item.date}T${String(item.hour + 1).padStart(2, '0')}:00:00`;

        // 過去預約不顯示
        if (new Date(endDateTime) < new Date()) return;

        const isFull = item.participants_count >= 14;
        let eventColor = '#22c55e';

        if (item.court_name.includes('B') || item.court_name.includes('b')) {
            eventColor = '#ef4444';
        }

        if (isFull) {
            eventColor = '#6b7280';
        }

        const fullText = isFull ? '(已滿團)' : `(${item.participants_count}/14人)`;
        const myPrefix = item.participants.includes(currentUser.student_id) ? '⭐ ' : '';

        calendar.addEvent({
            title: `${myPrefix}${item.court_name} ${fullText}`,
            start: startDateTime,
            end: endDateTime,
            color: eventColor,
            extendedProps: {
                reservation_id: item.id,
                participants_count: item.participants_count,
                court_name: item.court_name,
                participants: item.participants,
                host_id: item.host_id
            }
        });
    });
}

// 管理員載入待審核帳號
async function loadPendingUsers() {
    if (!currentUser || currentUser.role !== 'admin') return;

    const res = await fetch(`${API_BASE}/admin/pending?admin_id=${currentUser.student_id}`);
    const data = await res.json();

    const box = document.getElementById('pending-list');
    box.innerHTML = '';

    if (data.length === 0) {
        box.innerHTML = '<p>目前沒有待審核帳號。</p>';
        return;
    }

    data.forEach(user => {
        const div = document.createElement('div');
        div.className = 'admin-item';

        div.innerHTML = `
            <strong>${user.student_id}</strong>
            ｜姓名：${user.real_name || ''}
            ｜電話：${user.phone || ''}
            ｜原因：${user.reason || ''}
            <br>
            <button class="btn-admin" onclick="approveUser('${user.student_id}')">通過</button>
            <button class="btn-danger" onclick="rejectUser('${user.student_id}')">拒絕</button>
        `;

        box.appendChild(div);
    });
}

// 管理員通過帳號
async function approveUser(studentId) {
    const res = await fetch(`${API_BASE}/admin/users/${studentId}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ admin_id: currentUser.student_id })
    });

    const data = await res.json();
    alert(data.message || data.detail);

    loadPendingUsers();
    loadAllUsers();
}

// 管理員拒絕帳號
async function rejectUser(studentId) {
    const res = await fetch(`${API_BASE}/admin/users/${studentId}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ admin_id: currentUser.student_id })
    });

    const data = await res.json();
    alert(data.message || data.detail);

    loadPendingUsers();
    loadAllUsers();
}

// 管理員查看所有帳號
async function loadAllUsers() {
    if (!currentUser || currentUser.role !== 'admin') return;

    const res = await fetch(`${API_BASE}/admin/users?admin_id=${currentUser.student_id}`);
    const data = await res.json();

    const box = document.getElementById('user-list');
    box.innerHTML = '';

    data.forEach(user => {
        const div = document.createElement('div');
        div.className = 'admin-item';

        div.innerHTML = `
            <strong>${user.student_id}</strong>
            ｜role：${user.role}
            ｜status：${user.status}
            ｜姓名：${user.real_name || ''}
            ｜電話：${user.phone || ''}
        `;

        box.appendChild(div);
    });
}

// 管理員查詢某帳號有哪些預約
async function searchUserReservations() {
    const targetId = document.getElementById('search-user-id').value.trim();

    if (!targetId) {
        alert('請輸入要查詢的帳號');
        return;
    }

    const res = await fetch(`${API_BASE}/admin/user_reservations/${targetId}?admin_id=${currentUser.student_id}`);
    const data = await res.json();

    const box = document.getElementById('user-reservation-list');
    box.innerHTML = '';

    if (data.length === 0) {
        box.innerHTML = '<p>此帳號目前沒有預約。</p>';
        return;
    }

    data.forEach(r => {
        const div = document.createElement('div');
        div.className = 'admin-item';

        div.innerHTML = `
            ${r.date} ${String(r.hour).padStart(2, '0')}:00
            ${r.court_name}
            發起人：${r.host_id}
        `;

        box.appendChild(div);
    });
}