#py -m pip install fastapi uvicorn psycopg2-binary werkzeug
#py -m uvicorn main:app --reload
#cd C:\Users\User\Desktop\646464
#py -m http.server 5500



# main.py
# FastAPI 後端主程式
# 功能：
# 1. 登入
# 2. 非學生帳號申請
# 3. 預約、加入揪團、退出揪團、取消預約
# 4. 管理員審核帳號、查看帳號、查看預約

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import psycopg2
from psycopg2.extras import RealDictCursor
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import re

from credentials import STUDENT_CREDENTIALS, ADMIN_CREDENTIALS

app = FastAPI()

# 允許前端 5500 呼叫後端 8000
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# PostgreSQL 設定
# 如果你的 PostgreSQL 密碼不是 1234，只改 password
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "volleyball",
    "user": "postgres",
    "password": "1234"
}


def get_db_connection():
    """建立 PostgreSQL 連線"""
    return psycopg2.connect(**DB_CONFIG)


# 登入用資料格式
class LoginRequest(BaseModel):
    student_id: str
    password: str


# 非學生申請帳號用資料格式
class StaffApplyRequest(BaseModel):
    student_id: str
    password: str
    real_name: str
    phone: str
    reason: str


# 建立預約用資料格式
class ReservationCreate(BaseModel):
    student_id: str
    court_name: str
    date: str
    hour: int


# 加入、退出、取消預約用資料格式
class JoinLeaveAction(BaseModel):
    student_id: str


# 管理員操作用資料格式
class AdminAction(BaseModel):
    admin_id: str


def is_student_id_format(student_id: str) -> bool:
    """學生帳號格式：B144 + 4 碼數字"""
    return re.fullmatch(r"B144\d{4}", student_id) is not None


def parse_reservation_time(date: str, hour: int) -> datetime:
    """把日期與小時轉成 datetime"""
    try:
        return datetime.strptime(f"{date} {hour}:00", "%Y-%m-%d %H:%M")
    except ValueError:
        raise HTTPException(status_code=400, detail="日期或時間格式錯誤")


def is_past_slot(date: str, hour: int) -> bool:
    """判斷時段是否已經過去"""
    return parse_reservation_time(date, hour) < datetime.now()


def is_invalid_open_hour(date: str, hour: int) -> bool:
    """判斷是否不在開放時間內"""
    dt = parse_reservation_time(date, hour)
    weekday = dt.weekday()

    # 星期六、星期日：13:00 ~ 18:00
    if weekday in [5, 6]:
        return hour < 13 or hour >= 19

    # 星期一到星期五：09:00 ~ 20:00
    return hour < 9 or hour >= 21


def fetch_user(cursor, student_id: str):
    """查詢使用者"""
    cursor.execute("SELECT * FROM users WHERE student_id = %s", (student_id,))
    return cursor.fetchone()


def require_approved_user(cursor, student_id: str):
    """確認帳號存在且已通過審核"""
    user = fetch_user(cursor, student_id)

    if not user:
        raise HTTPException(status_code=401, detail="找不到此帳號")

    if user["status"] != "approved":
        raise HTTPException(status_code=403, detail="帳號尚未通過審核，無法操作")

    return user


def require_admin(cursor, admin_id: str):
    """確認操作者是管理員"""
    user = fetch_user(cursor, admin_id)

    if not user or user["role"] != "admin" or user["status"] != "approved":
        raise HTTPException(status_code=403, detail="只有管理員可以操作")

    return user


def seed_accounts():
    """
    後端啟動時，把 credentials.py 的帳號寫進資料庫。
    管理員寫進 users。
    學生寫進 credential_bank 和 users。
    """
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        # 建立管理員
        for admin in ADMIN_CREDENTIALS:
            cursor.execute(
                "SELECT student_id FROM users WHERE student_id = %s",
                (admin["admin_id"],)
            )

            if not cursor.fetchone():
                cursor.execute(
                    """
                    INSERT INTO users (student_id, password, role, status, real_name, phone, reason)
                    VALUES (%s, %s, 'admin', 'approved', %s, NULL, 'system_admin')
                    """,
                    (
                        admin["admin_id"],
                        generate_password_hash(admin["password"]),
                        admin["real_name"]
                    )
                )

        # 建立學生
        for s in STUDENT_CREDENTIALS:
            if not is_student_id_format(s["student_id"]):
                continue

            cursor.execute(
                "SELECT student_id FROM credential_bank WHERE student_id = %s",
                (s["student_id"],)
            )

            if not cursor.fetchone():
                cursor.execute(
                    """
                    INSERT INTO credential_bank (student_id, password, real_name)
                    VALUES (%s, %s, %s)
                    """,
                    (
                        s["student_id"],
                        generate_password_hash(s["password"]),
                        s["real_name"]
                    )
                )

            cursor.execute(
                "SELECT student_id FROM users WHERE student_id = %s",
                (s["student_id"],)
            )

            if not cursor.fetchone():
                cursor.execute(
                    """
                    INSERT INTO users (student_id, password, role, status, real_name, phone, reason)
                    VALUES (%s, %s, 'student', 'approved', %s, NULL, 'credential_bank')
                    """,
                    (
                        s["student_id"],
                        generate_password_hash(s["password"]),
                        s["real_name"]
                    )
                )

        conn.commit()

    finally:
        cursor.close()
        conn.close()


@app.on_event("startup")
def startup_event():
    """後端啟動時自動建立 credentials.py 裡的帳號"""
    try:
        seed_accounts()
    except Exception as e:
        print("database init failed:", e)


@app.post("/api/login")
def login(req: LoginRequest):
    """登入 API"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        user = fetch_user(cursor, req.student_id)

        if not user:
            raise HTTPException(status_code=401, detail="帳號或密碼錯誤")

        if user["status"] == "pending":
            raise HTTPException(status_code=403, detail="帳號審核中，請等待管理員通過")

        if user["status"] == "rejected":
            raise HTTPException(status_code=403, detail="帳號已被拒絕，無法登入")

        # 學生帳號必須存在 credential_bank
        if user["role"] == "student":
            cursor.execute(
                "SELECT * FROM credential_bank WHERE student_id = %s",
                (req.student_id,)
            )
            bank_user = cursor.fetchone()

            if not bank_user or not check_password_hash(bank_user["password"], req.password):
                raise HTTPException(status_code=401, detail="帳號或密碼錯誤")

        # 管理員與非學生帳號用 users 表驗證
        else:
            if not check_password_hash(user["password"], req.password):
                raise HTTPException(status_code=401, detail="帳號或密碼錯誤")

        return {
            "message": "登入成功",
            "student_id": user["student_id"],
            "role": user["role"],
            "status": user["status"],
            "real_name": user["real_name"],
            "phone": user["phone"]
        }

    finally:
        cursor.close()
        conn.close()


@app.post("/api/apply_staff")
def apply_staff(req: StaffApplyRequest):
    """非學生申請帳號"""
    if is_student_id_format(req.student_id):
        raise HTTPException(status_code=400, detail="學生帳號不能用申請流程")

    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        cursor.execute(
            "SELECT student_id FROM users WHERE student_id = %s",
            (req.student_id,)
        )

        if cursor.fetchone():
            return {"message": "此帳號已存在或已送出申請"}

        cursor.execute(
            """
            INSERT INTO users (student_id, password, role, status, real_name, phone, reason)
            VALUES (%s, %s, 'staff', 'pending', %s, %s, %s)
            """,
            (
                req.student_id,
                generate_password_hash(req.password),
                req.real_name,
                req.phone,
                req.reason
            )
        )

        conn.commit()
        return {"message": "申請已送出，請等待管理員審核"}

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=400, detail=str(e))

    finally:
        cursor.close()
        conn.close()


@app.get("/api/reservations")
def get_reservations():
    """取得所有預約"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        cursor.execute("SELECT * FROM reservations ORDER BY date, hour, court_name")
        reservations = cursor.fetchall()

        result = []

        for r in reservations:
            cursor.execute(
                "SELECT user_id FROM participants WHERE reservation_id = %s",
                (r["id"],)
            )

            participants = [row["user_id"] for row in cursor.fetchall()]

            result.append({
                "id": r["id"],
                "court_name": r["court_name"],
                "date": r["date"],
                "hour": r["hour"],
                "host_id": r["host_id"],
                "participants_count": len(participants),
                "participants": participants
            })

        return result

    finally:
        cursor.close()
        conn.close()


@app.post("/api/reservations")
def create_reservation(res: ReservationCreate):
    """建立預約"""
    if res.court_name not in ["A場", "B場"]:
        return {"message": "場地只能選擇 A場 或 B場"}

    if is_past_slot(res.date, res.hour):
        return {"message": "不能預約過去的日期或已經過去的時段"}

    if is_invalid_open_hour(res.date, res.hour):
        return {"message": "此時段不在開放時間內"}

    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        require_approved_user(cursor, res.student_id)

        cursor.execute(
            """
            SELECT * FROM reservations
            WHERE court_name = %s AND date = %s AND hour = %s
            """,
            (res.court_name, res.date, res.hour)
        )

        if cursor.fetchone():
            return {"message": "該時段已被預約"}

        cursor.execute(
            """
            INSERT INTO reservations (court_name, date, hour, host_id)
            VALUES (%s, %s, %s, %s)
            RETURNING id
            """,
            (res.court_name, res.date, res.hour, res.student_id)
        )

        new_id = cursor.fetchone()["id"]

        cursor.execute(
            """
            INSERT INTO participants (user_id, reservation_id)
            VALUES (%s, %s)
            """,
            (res.student_id, new_id)
        )

        conn.commit()
        return {"message": "預約成功"}

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=400, detail=str(e))

    finally:
        cursor.close()
        conn.close()


@app.post("/api/reservations/{res_id}/join")
def join_reservation(res_id: int, action: JoinLeaveAction):
    """加入揪團"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        require_approved_user(cursor, action.student_id)

        cursor.execute("SELECT * FROM reservations WHERE id = %s", (res_id,))
        reservation = cursor.fetchone()

        if not reservation:
            return {"message": "找不到這筆預約"}

        if is_past_slot(reservation["date"], reservation["hour"]):
            return {"message": "過去的預約不能再加入"}

        cursor.execute(
            "SELECT COUNT(*) AS count FROM participants WHERE reservation_id = %s",
            (res_id,)
        )

        count = cursor.fetchone()["count"]

        if count >= 14:
            return {"message": "揪團人數已達 14 人上限"}

        cursor.execute(
            """
            INSERT INTO participants (user_id, reservation_id)
            VALUES (%s, %s)
            """,
            (action.student_id, res_id)
        )

        conn.commit()
        return {"message": "成功加入揪團"}

    except psycopg2.errors.UniqueViolation:
        conn.rollback()
        return {"message": "你已經在這個揪團裡了"}

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=400, detail=str(e))

    finally:
        cursor.close()
        conn.close()


@app.post("/api/reservations/{res_id}/leave")
def leave_reservation(res_id: int, action: JoinLeaveAction):
    """退出揪團"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        require_approved_user(cursor, action.student_id)

        cursor.execute("SELECT * FROM reservations WHERE id = %s", (res_id,))
        reservation = cursor.fetchone()

        if not reservation:
            return {"message": "找不到這筆預約"}

        if is_past_slot(reservation["date"], reservation["hour"]):
            return {"message": "過去的預約不能操作"}

        if reservation["host_id"] == action.student_id:
            return {"message": "你是發起人，請使用取消整筆預約"}

        cursor.execute(
            """
            DELETE FROM participants
            WHERE user_id = %s AND reservation_id = %s
            """,
            (action.student_id, res_id)
        )

        conn.commit()
        return {"message": "已成功退出揪團"}

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=400, detail=str(e))

    finally:
        cursor.close()
        conn.close()


@app.delete("/api/reservations/{res_id}")
def delete_reservation(res_id: int, action: JoinLeaveAction):
    """取消整筆預約"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        user = require_approved_user(cursor, action.student_id)

        cursor.execute("SELECT * FROM reservations WHERE id = %s", (res_id,))
        reservation = cursor.fetchone()

        if not reservation:
            return {"message": "找不到這筆預約"}

        if is_past_slot(reservation["date"], reservation["hour"]):
            return {"message": "過去的預約不能取消"}

        if user["role"] != "admin" and reservation["host_id"] != action.student_id:
            return {"message": "只有發起人或管理員可以取消整筆預約"}

        cursor.execute("DELETE FROM reservations WHERE id = %s", (res_id,))
        conn.commit()

        return {"message": "預約已取消"}

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=400, detail=str(e))

    finally:
        cursor.close()
        conn.close()


@app.get("/api/admin/pending")
def admin_pending(admin_id: str = Query(...)):
    """管理員查看待審核帳號"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        require_admin(cursor, admin_id)

        cursor.execute(
            """
            SELECT student_id, role, status, real_name, phone, reason, created_at
            FROM users
            WHERE role = 'staff' AND status = 'pending'
            ORDER BY created_at
            """
        )

        return cursor.fetchall()

    finally:
        cursor.close()
        conn.close()


@app.post("/api/admin/users/{student_id}/approve")
def approve_user(student_id: str, action: AdminAction):
    """管理員通過帳號申請"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        require_admin(cursor, action.admin_id)

        cursor.execute(
            """
            UPDATE users
            SET status = 'approved'
            WHERE student_id = %s AND role = 'staff'
            """,
            (student_id,)
        )

        conn.commit()
        return {"message": "已通過申請"}

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=400, detail=str(e))

    finally:
        cursor.close()
        conn.close()


@app.post("/api/admin/users/{student_id}/reject")
def reject_user(student_id: str, action: AdminAction):
    """管理員拒絕帳號申請"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        require_admin(cursor, action.admin_id)

        cursor.execute(
            """
            UPDATE users
            SET status = 'rejected'
            WHERE student_id = %s AND role = 'staff'
            """,
            (student_id,)
        )

        conn.commit()
        return {"message": "已拒絕申請"}

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=400, detail=str(e))

    finally:
        cursor.close()
        conn.close()


@app.get("/api/admin/users")
def admin_users(admin_id: str = Query(...)):
    """管理員查看所有帳號"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        require_admin(cursor, admin_id)

        cursor.execute(
            """
            SELECT student_id, role, status, real_name, phone, reason, created_at
            FROM users
            ORDER BY role, student_id
            """
        )

        return cursor.fetchall()

    finally:
        cursor.close()
        conn.close()


@app.get("/api/admin/user_reservations/{student_id}")
def admin_user_reservations(student_id: str, admin_id: str = Query(...)):
    """管理員查看指定帳號有哪些預約"""
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)

    try:
        require_admin(cursor, admin_id)

        cursor.execute(
            """
            SELECT r.id, r.court_name, r.date, r.hour, r.host_id
            FROM reservations r
            JOIN participants p ON r.id = p.reservation_id
            WHERE p.user_id = %s
            ORDER BY r.date, r.hour
            """,
            (student_id,)
        )

        return cursor.fetchall()

    finally:
        cursor.close()
        conn.close()