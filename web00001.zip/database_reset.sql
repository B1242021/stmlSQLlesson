-- database_reset.sql
-- 這個檔案用來重建資料庫。
-- 每次大改資料表欄位時，都重新執行一次。

DROP TABLE IF EXISTS participants CASCADE;
DROP TABLE IF EXISTS reservations CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS credential_bank CASCADE;

-- 學生帳密庫
CREATE TABLE credential_bank (
    student_id VARCHAR(30) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    real_name VARCHAR(50)
);

-- 使用者表
CREATE TABLE users (
    student_id VARCHAR(30) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'student',
    status VARCHAR(20) NOT NULL DEFAULT 'approved',
    real_name VARCHAR(50),
    phone VARCHAR(20),
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (role IN ('student', 'staff', 'admin')),
    CONSTRAINT users_status_check CHECK (status IN ('approved', 'pending', 'rejected'))
);

-- 預約表
CREATE TABLE reservations (
    id SERIAL PRIMARY KEY,
    court_name VARCHAR(10) NOT NULL,
    date VARCHAR(10) NOT NULL,
    hour INTEGER NOT NULL,
    host_id VARCHAR(30) REFERENCES users(student_id),
    UNIQUE (court_name, date, hour)
);

-- 參與者表
CREATE TABLE participants (
    user_id VARCHAR(30) REFERENCES users(student_id),
    reservation_id INTEGER REFERENCES reservations(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, reservation_id)
);